﻿using System;
using AssignmentDataLayer;
using System.Data.OleDb;
using System.Web;
using System.Web.UI.WebControls;
using System.IO;
using System.Configuration;

namespace AssignmentBusinessLayer
{
    public class AssignmentBusiness
    {
        #region Fields
        private AssignmentData _data;

        //public int tsCategoryID { get; private set; }
        #endregion

        #region Constructors

        public AssignmentBusiness()
        {
            OleDbConnectionStringBuilder sb = new OleDbConnectionStringBuilder();
            sb.Provider = "Microsoft.ACE.OLEDB.12.0"; 
            sb.DataSource = HttpContext.Current.Server.MapPath("/batanb02/uploads/AssignUpload/QTShirtDB.accdb");

            //sb.Provider = ConfigurationManager.AppSettings["Provider"];
            //sb.DataSource = HttpContext.Current.Server.MapPath(ConfigurationManager.AppSettings["DatabasePath"]);

            _data = new AssignmentData(sb.ConnectionString);
        }

        #endregion

        #region Open methods

        //display all products
        public void DisplayDelegates(DataList dlstDataList)
        {
            _data.OpenConnection();
            //Retrieve the data and display by using a Dropdown List
            //ddlRegID.DataSource = _data.GetCustomers();
            //ddlRegID.DataBind();
            //_data.CloseReader();

            //Retrieve the data and display by using a DataList
            dlstDataList.DataSource = _data.GetTShirt();
            dlstDataList.DataBind();
            _data.CloseReader();

            _data.CloseConnection();
        }

        //display men's category
        public void DisplayMen(DataList dlstDataList)
        {
            _data.OpenConnection();

            int tsCategoryID = 1;
            dlstDataList.DataSource = _data.GetTSCategory(tsCategoryID);
            dlstDataList.DataBind(); 
            _data.CloseReader();

            _data.CloseConnection();
        }

        public string SaveFile(FileUpload fileObject, string virtualPath, string fieldName, int idNumber)
        {
            _data.OpenConnection();

            string sqlQuery = "Update Customers Set " + fieldName + " = '" + virtualPath + "' Where [CustomerID] = " + idNumber.ToString();
            _data.UpdateCustomer(sqlQuery);

            fileObject.PostedFile.SaveAs(HttpContext.Current.Server.MapPath(virtualPath));

            _data.CloseConnection();

            string result = "File uploaded successfully to <b>" + HttpContext.Current.Server.MapPath(virtualPath) +
                            "</b> on the Web server";
            return result;
        }

        public void SaveLog(string logLine)
        {
            StreamWriter streamWriter =
                System.IO.File.AppendText(HttpContext.Current.Server.MapPath("/batanb02/uploads/AssignUpload/AssignmentLog.txt"));
            streamWriter.WriteLine(DateTime.Now.ToString() + " : " + logLine);
            streamWriter.Close();
        }

        /// <summary>
        /// Validate input username and password
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public bool CheckDatabase(string username, string password)
        {
            bool result = false;
            OleDbDataReader reader;
            //Open connection
            _data.OpenConnection();
            reader = _data.GetUsers(username);
            if (reader.HasRows)
            {
                reader.Close();
                //check for password
                reader = _data.GetPasswords(username, password);
                if (reader.HasRows) // Found correspondance
                {
                    HttpContext.Current.Session["Username"] = username;
                    HttpContext.Current.Session["Password"] = password;
                    result = true;
                }
                else // no correspondance
                {
                    HttpContext.Current.Session.Abandon();
                }
            }
            else
            {
                HttpContext.Current.Session.Abandon();
            }

            reader.Close();

            //Close connection
            _data.CloseConnection();
            return result;
        }

        #endregion
    }
}
