﻿using System;
using System.Text;
using System.Globalization;
using System.Web;
using System.IO;

namespace AHelpers
{
    public class Assignment
    {
        public static double TotalCost(double Price, double Quantity)
        {
            double result = Price * Quantity;
            return result;
        }
    }
}
