﻿using System;
using System.Data;
using System.Data.OleDb;

namespace AssignmentDataLayer
{
    public class AssignmentData
    {
        #region Fields - Instance variables
        private string _connectionString = "";
        private OleDbConnection _connection;
        private OleDbCommand _sqlCommand;
        private OleDbDataReader _reader;
        #endregion

        #region Properties - available properties of the class

        public string ConnectionString
        {
            get { return _connectionString; }
            set { _connectionString = value; }
        }

        public OleDbConnection Connection
        {
            get { return _connection; }
        }

        #endregion

        #region Constructors
        public AssignmentData(string connectionString)
        {
            _connectionString = connectionString;
            _connection = new OleDbConnection(_connectionString);
            _sqlCommand = new OleDbCommand("", _connection);
        }
        #endregion

        #region Public methods

        /// <summary>
        /// Checks whether connection object exists
        /// and open new connection session
        /// </summary>
        public void OpenConnection()
        {
            if (_connection != null)
            {
                _connection.Open();
            }
        }

        /// <summary>
        /// Checks whether connection object exists and if it exists whether the state is not closed.
        /// If all of the above is true, close the connection session
        /// </summary>
        public void CloseConnection()
        {
            if (_connection != null && _connection.State != ConnectionState.Closed)
            {
                _connection.Close();
            }
        }

        /// <summary>
        /// Checks whether reader object exists and if it exists, checks its state
        /// If state is not closed, then close reader
        /// </summary>
        public void CloseReader()
        {
            if (_reader != null && !_reader.IsClosed)
            {
                _reader.Close();
            }
        }

        /// <summary>
        /// If connection is open then the method executes specific query: "select * from Customers" 
        /// in the connected database.
        /// </summary>
        /// <returns>DataReader with data about customers</returns>
        public OleDbDataReader GetCustomers()
        {
            if (_connection.State == ConnectionState.Open)
            {
                string sqlQuery = "select * from Customers";
                _sqlCommand.CommandText = sqlQuery;
                _reader = _sqlCommand.ExecuteReader();
            }
            return _reader;
        }

        /// <summary>
        /// If connection is open then the method executes query from sqlString parameter 
        /// </summary>
        /// <param name="sqlString">sql query that is to contain update customer command</param>
        public void UpdateCustomer(string sqlString)
        {
            if (_connection.State == ConnectionState.Open)
            {
                _sqlCommand.CommandText = sqlString;
                _sqlCommand.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Select a use with the given username
        /// </summary>
        /// <param name="username"></param>
        /// <returns></returns>
        public OleDbDataReader GetUsers(string username)
        {
            if (_connection.State == ConnectionState.Open)
            {

                string query = "SELECT * FROM Customers WHERE [Username] = @Username";
                _sqlCommand.CommandText = query;
                _sqlCommand.Parameters.Clear();
                _sqlCommand.Parameters.Add(new OleDbParameter("@Username", username));
                return _sqlCommand.ExecuteReader();
            }

            return null;
        }

        /// <summary>
        /// Selec a record with the given username and password
        /// </summary>
        /// <param name="username"></param>
        /// <param name="password"></param>
        /// <returns></returns>
        public OleDbDataReader GetPasswords(string username, string password)
        {
            if (_connection.State == ConnectionState.Open)
            {
                string query = "SELECT * FROM Customers WHERE [Password] = @Password AND [Username] = @Username";
                _sqlCommand.CommandText = query;
                _sqlCommand.Parameters.Clear();
                _sqlCommand.Parameters.Add(new OleDbParameter("@Password", password));
                _sqlCommand.Parameters.Add(new OleDbParameter("@Username", username));

                return _sqlCommand.ExecuteReader();

            }
            return null;
        }

        /// <summary>
        /// If connection is open then the method executes specific query: "select * from TShirt" 
        /// in the connected database.
        /// </summary>
        /// <returns>DataReader with data about Products</returns>
        public OleDbDataReader GetTShirt()
        {
            if (_connection.State == ConnectionState.Open)
            {
                string sqlQuery = "select * from TShirt";
                _sqlCommand.CommandText = sqlQuery;
                _reader = _sqlCommand.ExecuteReader();
            }
            return _reader;
        }

        //Select Men's Category from TShirt
        public OleDbDataReader GetTSCategory(int tsCategoryID)
        {
            if (_connection.State == ConnectionState.Open)
            {
                string sqlQuery = "select * from TShirt WHERE[TSCategoryID] = @TSCategoryID";
                _sqlCommand.CommandText = sqlQuery;
                _sqlCommand.Parameters.Clear();
                _sqlCommand.Parameters.Add(new OleDbParameter("@TSCategoryID", tsCategoryID));
                _reader = _sqlCommand.ExecuteReader();
            }
            return _reader;
        }

        #endregion
    }
}
