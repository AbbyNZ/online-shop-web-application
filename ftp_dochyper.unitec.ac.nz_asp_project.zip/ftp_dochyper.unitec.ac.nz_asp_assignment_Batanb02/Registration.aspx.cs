﻿using System;
using System.Data.OleDb;
using System.Text;
using System.Data;
//using System.Configuration;

public partial class Registration : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (this.IsPostBack)
        {
            //Display greetings
            lblOutput.Text = "Welcome " + txtFName.Text + "!";

            SaveRegistration();
        }
    }

    private void SaveRegistration()
    {
        OleDbConnectionStringBuilder sb = new OleDbConnectionStringBuilder();
        sb.Provider = "Microsoft.ACE.OLEDB.12.0";
        sb.DataSource = Server.MapPath("/batanb02/uploads/AssignUpload/QTShirtDB.accdb");

        //sb.Provider = ConfigurationManager.AppSettings["Provider"];
        //sb.DataSource = Server.MapPath(ConfigurationManager.AppSettings["DatabasePath"]);

        //The following describes connection parameters (connection string) to SQL Server
        //Initial Catalog, Login and Password you need specify
        //sb.Provider = "SQLOLEDB";
        //sb.DataSource = "dochyper.unitec.ac.nz";
        //sb.Add("Initial Catalog", "YOURLOGINsqlserver1");
        //sb.Add("User ID","YOURLOGIN");
        //sb.Add("Password","********");

        OleDbConnection myConnection = new OleDbConnection(sb.ConnectionString);
        string queryString = "";
        OleDbCommand myCmd = new OleDbCommand(queryString, myConnection);

        try
        {

            myConnection.Open();

            StringBuilder queryStringBuilder = new StringBuilder("Insert into Customers([LastName], [FirstName], [Username], [Phone], [Email], [Address], [Suburb], [Postcode], [Password])");

            queryStringBuilder.Append("values ('");
            queryStringBuilder.Append(txtLName.Text);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(txtFName.Text);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(txtUName.Text);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(txtMobile.Text);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(txtEMail.Text);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(txtAddress.Text);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(txtSuburb.Text);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(txtPostcode.Text);
            queryStringBuilder.Append("','");
            queryStringBuilder.Append(txtPassword.Text);
            queryStringBuilder.Append("')");

            queryString = queryStringBuilder.ToString();

            myCmd.CommandText = queryString;
            myCmd.ExecuteNonQuery();

            //Create another command object
            OleDbCommand anotherCmd = new OleDbCommand("SELECT @@IDENTITY", myConnection);
            int numId = Convert.ToInt32(anotherCmd.ExecuteScalar());

            lblDataId.Text = "<h3>Your registration number is <big>" + numId.ToString() + "</big></h3>";

        }
        catch (OleDbException exOleDb)
        {
            Session["ExceptionObject"] = exOleDb;
            Server.Transfer("DisplayErrors.aspx?from=Catch OleDb");
        }
        catch (Exception exGeneral)
        {
            Session["ExceptionObject"] = exGeneral;
            Server.Transfer("DisplayErrors.aspx?from=Catch General");
        }
        finally
        {
            if (myConnection != null && myConnection.State == ConnectionState.Open)
            {
                myConnection.Close();
            }
        }

        //myConnection.Close();
    }

    //Added for error handling
    protected override void OnError(EventArgs e)
    {
        Exception ex = Server.GetLastError();
        Session["ExceptionObject"] = ex;
        //Server.ClearError();
        //Server.Transfer("DisplayErrors.aspx?from=RegistrationPage");
    }
}