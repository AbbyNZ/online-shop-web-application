﻿using System;
using AHelpers;
using System.IO;
using AssignmentBusinessLayer;

public partial class ProductList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            AssignmentBusiness business = new AssignmentBusiness();
            business.DisplayDelegates(dlstDataList);
        }
    }
}