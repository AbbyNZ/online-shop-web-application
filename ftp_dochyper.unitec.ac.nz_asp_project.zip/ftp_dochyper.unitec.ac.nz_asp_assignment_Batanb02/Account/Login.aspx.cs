﻿using Microsoft.AspNet.Identity;
using System.Security.Claims;
using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI.WebControls;
using AssignmentBusinessLayer;

public partial class Login : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        RegisterHyperLink.NavigateUrl = "~/Registration.aspx";

        lgnUserLogin.Authenticate += new AuthenticateEventHandler(lgnUserLogin_Authenticate);
    }

    protected void lgnUserLogin_Authenticate(object sender, AuthenticateEventArgs e)
    {

        AssignmentBusiness business = new AssignmentBusiness();

        if (business.CheckDatabase(lgnUserLogin.UserName.Trim(), lgnUserLogin.Password))
        {
            var claims = new List<Claim>();
            claims.Add(new Claim(ClaimTypes.Name, lgnUserLogin.UserName.Trim()));
            claims.Add(new Claim(ClaimTypes.Role, "Customer"));
            claims.Add(new Claim(ClaimTypes.Role, "Administrator"));
            claims.Add(new Claim(ClaimTypes.IsPersistent, lgnUserLogin.RememberMeText));
            var id = new ClaimsIdentity(claims, DefaultAuthenticationTypes.ApplicationCookie);
            var ctx = Request.GetOwinContext();
            var authenticationManager = ctx.Authentication;
            authenticationManager.SignIn(id);
        }
    }
}