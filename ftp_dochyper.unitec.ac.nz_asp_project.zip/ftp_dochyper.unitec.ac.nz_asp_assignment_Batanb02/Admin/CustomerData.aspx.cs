﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;

public partial class CustomerData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        gvCustomer.SelectedIndexChanged += new EventHandler(gvSimple_SelectedIndexChanged);
    }

    protected void gvSimple_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Write("<br/>gvCustomer.SelectedIndex = " + gvCustomer.SelectedIndex.ToString());
        Response.Write("<br/>gvCustomer.SelectedValue = " + gvCustomer.SelectedValue.ToString());
    }
}