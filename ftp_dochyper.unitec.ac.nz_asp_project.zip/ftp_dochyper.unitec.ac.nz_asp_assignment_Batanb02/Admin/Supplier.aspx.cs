﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;


public partial class Supplier : System.Web.UI.Page
{
    private OleDbConnection _myConnection;

    protected void Page_Load(object sender, EventArgs e)
    {
        OleDbConnectionStringBuilder sb = new OleDbConnectionStringBuilder();
        sb.Provider = "Microsoft.ACE.OLEDB.12.0";
        sb.DataSource = Server.MapPath("/batanb02/uploads/AssignUpload/QTShirtDB.accdb");
        _myConnection = new OleDbConnection(sb.ConnectionString);

        if (!this.IsPostBack)
        {
            this.BindGrid();
        }
    }

    public void BindGrid()
    {
        string strQuery = "Select * from Supplier";
        OleDbDataAdapter dataAdapter = new OleDbDataAdapter(strQuery, _myConnection);
        DataSet ds = new DataSet();
        string tableName = "Supplier";
        dataAdapter.Fill(ds, tableName);

        myDataGrid.DataSource = ds.Tables[tableName].DefaultView;
        myDataGrid.DataBind();
    }

    public void AddCompany_Click(object sender, EventArgs e)
    {
        //DataSet ds;
        OleDbCommand myCommand;
        if (com_name.Value == "")
        {
            Message.InnerHtml = "ERROR: Null values not allowed for Supplier Name";
            Message.Style["color"] = "red";
            this.BindGrid();
        }

        string insertCmd = "INSERT INTO Supplier(SupplierName, Address, Country, Phone, EmailAddress) VALUES(@SupplierName, @Address, @Country, @Phone, @EmailAddress)";
        myCommand = new OleDbCommand(insertCmd, _myConnection);
        myCommand.Parameters.Add(new OleDbParameter("@SupplierName", OleDbType.Char));
        myCommand.Parameters["@SupplierName"].Value = com_name.Value;
        myCommand.Parameters.Add(new OleDbParameter("@Address", OleDbType.Char));
        myCommand.Parameters["@Address"].Value = com_address.Value;
        myCommand.Parameters.Add(new OleDbParameter("@Country", OleDbType.Char));
        myCommand.Parameters["@Country"].Value = com_country.Value;
        myCommand.Parameters.Add(new OleDbParameter("@Phone", OleDbType.Char));
        myCommand.Parameters["@Phone"].Value = com_phone.Value;
        myCommand.Parameters.Add(new OleDbParameter("@EmailAddress", OleDbType.Char));
        myCommand.Parameters["@EmailAddress"].Value = com_email.Value;

        myCommand.Connection.Open();
        Message.InnerHtml = myCommand.Parameters["@SupplierName"].Value + insertCmd + myCommand.Parameters["@Address"].Value + insertCmd + myCommand.Parameters["@Country"].Value + insertCmd + myCommand.Parameters["@Phone"].Value + insertCmd + myCommand.Parameters["@EmailAddress"].Value;
        myCommand.ExecuteNonQuery();
        Message.InnerHtml = "<b>Record Added</b><br/>" + insertCmd;
        myCommand.Connection.Close();
        this.BindGrid();
    }
     
}