﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class OrderList : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        gvOrderItems.SelectedIndexChanged += new EventHandler(gvOrderItems_SelectedIndexChanged);
    }

    protected void gvOrderItems_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Write("<br/>gvOrderItems.SelectedIndex = " + gvOrderItems.SelectedIndex.ToString());
        Response.Write("<br/>gvOrderItems.SelectedValue = " + gvOrderItems.SelectedValue.ToString());
    }
}