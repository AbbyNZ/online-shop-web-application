﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;

public partial class CustomerOrderData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        gvCustomerOrder.SelectedIndexChanged += new EventHandler(gvCustomerOrder_SelectedIndexChanged);
    }

    protected void gvCustomerOrder_SelectedIndexChanged(object sender, EventArgs e)
    {
        Response.Write("<br/>gvCustomerOrder.SelectedIndex = " + gvCustomerOrder.SelectedIndex.ToString());
        Response.Write("<br/>gvCustomerOrder.SelectedValue = " + gvCustomerOrder.SelectedValue.ToString());
    }
}