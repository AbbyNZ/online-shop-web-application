﻿using System;
using System.Web.UI.WebControls;
using System.Data;
using System.Data.OleDb;
using System.Linq;
using System.Collections;


public partial class ShoppingCart : System.Web.UI.Page
{
    private OleDbDataAdapter myAdapter;
    //private OleDbDataAdapter adapterOrderItems;
    //private OleDbDataAdapter adapterCustomerOrders;
    private DataSet dataset = new DataSet();
    private string strOrderItems = "OrderItems";
    private string strCustomerOrders = "CustomerOrders";
    private string TotalCost;

    private DataRow newRowCustomerOrders;
    private ArrayList selectedKeys = new ArrayList();

    protected void Page_Load(object sender, EventArgs e)
    {
        // Put user code to initialize the page here
        OleDbConnectionStringBuilder sb = new OleDbConnectionStringBuilder();
        sb.Provider = "Microsoft.ACE.OLEDB.12.0";
        sb.DataSource = Server.MapPath("/batanb02/uploads/AssignUpload/QTShirtDB.accdb");

        OleDbConnection conn = new OleDbConnection(sb.ConnectionString);
        //string queryCustomerOrders = "SELECT * FROM CustomerOrders";
        string queryOrderItems = "SELECT [TShirtID],[TSName], [Colour], [Quantity], [Price], [TotalCost] FROM OrderItems";
        //adapterCustomerOrders = new OleDbDataAdapter(queryCustomerOrders, conn);
        //adapterOrderItems = new OleDbDataAdapter(queryOrderItems, conn);
        myAdapter = new OleDbDataAdapter(queryOrderItems, conn);

        //Event handlers
        dlstDataList.ItemCommand += new DataListCommandEventHandler(dlstDataList_ItemCommand);
        CheckOut.Click += new EventHandler(CheckOut_Click);
        Clear.Click += new EventHandler(Clear_Click);

        //if first time page has loaded
        if (!this.IsPostBack)
        {
            LoadTShirts();

            //Load table
            //No need to open and close connection. DataAdapter does it.
            
            //adapterCustomerOrders.Fill(dataset, strCustomerOrders);
            myAdapter.Fill(dataset, strOrderItems);
            dataset.Clear();
            

            newRowCustomerOrders = dataset.Tables[strCustomerOrders].NewRow();
            newRowCustomerOrders["Status"] = "Waiting";
            newRowCustomerOrders["CustomerID"] = 1;
            dataset.Tables[strCustomerOrders].Rows.Add(newRowCustomerOrders);
            SCart.Text = Convert.ToString(dataset.Tables[strCustomerOrders].Rows.Count);
            this.Session["CustomerOrders"] = dataset;
        }
    }

    public void LoadTShirts()
    {
        // Put user code to initialize the page here
        OleDbConnectionStringBuilder sb = new OleDbConnectionStringBuilder();
        sb.Provider = "Microsoft.ACE.OLEDB.12.0";
        sb.DataSource = Server.MapPath("/batanb02/uploads/AssignUpload/QTShirtDB.accdb");

        OleDbConnection conn = new OleDbConnection(sb.ConnectionString);
        string strquery = "SELECT * FROM TShirt";
        OleDbCommand cmd = new OleDbCommand(strquery, conn);

        //Open connection
        conn.Open();

        //Retrieve the data and display by using a DataList
        OleDbDataReader myreader = cmd.ExecuteReader();
        dlstDataList.DataSource = myreader;
        dlstDataList.DataBind();
        myreader.Close();

        //Close the connection
        if (conn != null)
        {
            conn.Close();
        }
    }

    //Shopping Cart
    protected void dlstDataList_ItemCommand(object sender, System.Web.UI.WebControls.DataListCommandEventArgs e)
    {
        dataset = this.Session["CustomerOrders"] as DataSet;


        DataRow newRowOrderItems;
        Label lblTSName = e.Item.FindControl("TSName") as Label;
        Label lblColour = e.Item.FindControl("Colour") as Label;
        Label lblPrice = e.Item.FindControl("Price") as Label;
        int rowNumCustomerOrders = dataset.Tables[strCustomerOrders].Rows.Count;
        int rowNumOrderItems = dataset.Tables[strOrderItems].Rows.Count;
        bool firstTime = true;

        //checks if it is the first time the shirt is clicked
        for (int i = 0; i < rowNumOrderItems; i++)
        {
            if (Convert.ToInt32(dataset.Tables[strOrderItems].Rows[i]["TShirtID"]) == Convert.ToInt32(dlstDataList.DataKeys[e.Item.ItemIndex]))
            {
                dataset.Tables[strOrderItems].Rows[i]["Quantity"] = Convert.ToInt32(dataset.Tables[strOrderItems].Rows[i]["Quantity"]) + 1;
                firstTime = false;
                break;
            }
        }

        if (firstTime)
        {
            newRowOrderItems = dataset.Tables[strOrderItems].NewRow();
            newRowOrderItems["TShirtID"] = dlstDataList.DataKeys[e.Item.ItemIndex];
            newRowOrderItems["TSName"] = lblTSName.Text;
            newRowOrderItems["Colour"] = lblColour.Text;
            newRowOrderItems["Quantity"] = 1;
            newRowOrderItems["Price"] = lblPrice.Text;
            //newRowOrderItems["TotalCost"] = (Convert.ToInt32("Quantity")) * (Convert.ToInt32("Price"));
            newRowOrderItems["TotalCost"] = String.Format("{0:C}", (Convert.ToDouble("Quantity")) * (Convert.ToDouble("Price")));
            dataset.Tables[strOrderItems].Rows.Add(newRowOrderItems);
        }

        this.Session["CustomerOrders"] = dataset;
        //dataset.Tables[strOrderItems].DefaultView.RowFilter = ("OrderListID IS NULL");
        gvItems.DataSource = dataset;             //.Tables[strOrderItems].DefaultView;
        gvItems.DataBind();

    }

    public void CheckOut_Click(object sender, EventArgs e)
    {
        //Customer needs to login first if he/she is not a registered user.
        if(IsValid)
        {
            
            bool isLoggedOn = true;
      
            if(!isLoggedOn)
            {
                Response.Redirect("~/Admin/Login.aspx");
            }

            SaveShoppingCart();
        }

    }

    public void SaveShoppingCart()
    {
        //Create a command builder to generate the SQL statements
        OleDbCommandBuilder cbCustomerOrders = new OleDbCommandBuilder(myAdapter);


        cbCustomerOrders.QuotePrefix = "[";
        cbCustomerOrders.QuoteSuffix = "]";
        dataset = this.Session["CustomerOrders"] as DataSet;

        //Update database
        //adapterCustomerOrders.Update(dataset, strCustomerOrders);
        myAdapter.Update(dataset, strOrderItems);

        //dataset = this.Session[strCustomerOrders] as DataSet;
        dataset.Clear();
        //adapterCustomerOrders.Fill(dataset, strCustomerOrders);
        //adapterOrderItems.Fill(dataset, strOrderItems);
        this.Session[strCustomerOrders] = dataset;
        gvItems.DataSource = dataset;
        gvItems.DataBind();

    }

    protected void Clear_Click(object sender, EventArgs e)
    {
        dataset = this.Session[strCustomerOrders] as DataSet;
        dataset.Clear();
        this.Session[strCustomerOrders] = dataset;
        gvItems.DataSource = dataset;
        gvItems.DataBind();

    }

}    
