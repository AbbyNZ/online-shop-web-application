﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;

public partial class QTSSite : System.Web.UI.MasterPage
{
    string[] Banners = new string[3] { "TShirtLogo1a.jpg", "TShirtLogo2a.png", "TShirtLogo3a.jpg" };

    protected void Page_Load(object sender, EventArgs e)
    {
        //Initialise the banner
        if (ViewState["bIndex"] == null)
        {
            ViewState["bIndex"] = 0;
            imgBanner.ImageUrl = "AImages/" + Banners[0];
        }
    }

    protected void Timer1_Tick(object sender, EventArgs e)
    {

        int i = Int32.Parse(ViewState["bIndex"].ToString());

        //Update the index
        i = (i + 1) % 3;
        ViewState["bIndex"] = i;

        //Set the image
        imgBanner.ImageUrl = "AImages/" + Banners[i];

    }
}
