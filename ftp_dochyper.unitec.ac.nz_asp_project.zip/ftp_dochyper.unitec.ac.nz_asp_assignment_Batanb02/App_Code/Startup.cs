﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(asp_assignment.Startup))]
namespace asp_assignment
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
