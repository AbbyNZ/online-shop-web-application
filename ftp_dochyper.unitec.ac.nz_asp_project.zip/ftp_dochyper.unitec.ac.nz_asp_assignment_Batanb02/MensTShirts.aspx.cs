﻿using System;
using System.IO;
using System.Data.OleDb;
using AssignmentBusinessLayer;

public partial class MensTShirts : System.Web.UI.Page
{
    private OleDbConnection _conn;

    protected void Page_Load(object sender, EventArgs e)
    {
        AssignmentBusiness business = new AssignmentBusiness();
        business.DisplayMen(dlstDataList);
    }
}